<?php

namespace App\Http\Controllers;

use App\Models\School;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class SchoolsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $school = School::paginate(2);
        return view('schools.index',['school'=>$school]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('schools.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name'=>'required',
            'address'=>'required',
            'year'=>'required',
            'student'=>'required',
            'image'  => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',

        ]);
        //untuk simpan
       
        $image = $request->file('image');
        $image->storeAs('public/images', $image->hashName());
        School::create([
            'name'     => $request->name,
            'address'   => $request->address,
            'year'     => $request->year,
            'student'   => $request->student,
            'image'     => $image->hashName(),
        ]);

        //kembali
        return redirect()->route('school.index')->with('success','data edited');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(School $school)
    {
        return view('schools.show',['school'=>$school]);

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(School $school)
    {
        return view('schools.edit',['school'=>$school]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,School $school)
    {
        $request->validate([
            'name'=>'required',
            'address'=>'required',
            'year'=>'required',
            'student'=>'required',
            'image'     => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',

        ]);
        //untuk simpan
    // $school->update($request->all());
    if ($request->hasFile('image')) {

        //upload new image
        $image = $request->file('image');
        $image->storeAs('public/images', $image->hashName());

        //delete old image
        Storage::delete('public/images/'.$school->image);

        //update post with new image
        $school->update([
            'name'     => $request->name,
            'address'   => $request->address,
            'year'     => $request->year,
            'student'   => $request->student,
            'image'     => $image->hashName(),
        ]);

    } else {

        //update post without image
        $school->update([
            'name'     => $request->name,
            'address'   => $request->address,
            'year'     => $request->year,
            'student'   => $request->student,
        ]);
    }

        //kembali
        return redirect()->route('school.index')->with('success','data edited');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(School $school)
    {
        Storage::delete('public/images/'. $school->image);

        //delete post
        $school->delete();

        //redirect to index
       
        return redirect()->route('school.index')->with('success','data telah dihapus');
    }
}
