@extends('schools.layout')

@section('school')

<h3>{{ $school->name }}</h3>

<p>addres: <h3>{{ $school->address }}</h3></p>
<p>year :{{ $school->year }}</p>
<p>student :{{ $school->student }}</p>

<a href="{{ route('school.index') }}" class="btn btn-secondary">Back to Index</a>
@endsection