<?php $__env->startSection('school'); ?>

<h3><?php echo e($school->name); ?></h3>

<p>address:<?php echo e($school->address); ?></p>
<p>year :<?php echo e($school->year); ?></p>
<p>student :<?php echo e($school->student); ?></p>

<a href="<?php echo e(route('school.index')); ?>" class="btn btn-secondary">Back to Index</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('schools.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Desktop/school-app/resources/views/schools/show.blade.php ENDPATH**/ ?>