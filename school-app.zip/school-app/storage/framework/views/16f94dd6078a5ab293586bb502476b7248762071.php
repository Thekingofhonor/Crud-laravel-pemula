<?php $__env->startSection('school'); ?>
<form action="<?php echo e(route('school.store')); ?>" method="post" enctype="multipart/form-data" class="form">
    <?php echo csrf_field(); ?>
    <label for="">Name </label><br>
    <input type="text" name="name"><br>
    <label for="">address</label><br>
    <input type="text" name="address"><br>
    <label for="">year</label><br>
    <input type="number" name="year"><br>
    <label for="">student</label><br>
    <input type="number" name="student"><br>
    <label for="">Upload image</label>
    <input type="file" name="image" id=""><br><br>

    <input type="submit" value="Save"class="btn btn-primary" . > <button type="reset" class="btn btn-md btn-dark">Reset</button>


</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('schools.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Desktop/school-app/resources/views/schools/create.blade.php ENDPATH**/ ?>