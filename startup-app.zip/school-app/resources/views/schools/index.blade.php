
@extends('schools.layout')

@section('school')
<a href="{{route('school.create')}}" class="btn btn-primary">ADD</a>
<table class="table">
    <tr>
        <th>Id</th>
        <th>image</th>
        <th>nama</th>
        <th>address</th>
        <th>year</th>
        <th>student</th>
        <th>action</th>

    </tr>
    @foreach($school as $p)
    <tr>
        <td>{{$p->id}}</td>
        <td><img src="{{Storage::url('public/images/'. $p->image)}}" style="width: 150px;" alt=""></td>
        <td>{{$p->name}}</td>
        <td>{{$p->address}}</td>
        <td>{{$p->year}}</td>
        <td>{{$p->student}}</td>
        <td>
            <a href="{{route('school.show',$p->id)}}" class="btn btn-success">Details</a>
            <a href="{{route('school.edit',$p->id)}}" class="btn btn-secondary">edit</a>
            <form action="{{ route('school.destroy', $p->id) }}" method="POST" style="display: inline;">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-danger">DELETE</button>
            </form></td> </tr>
    @endforeach
 
</table>{{ $school->links() }}  @endsection 