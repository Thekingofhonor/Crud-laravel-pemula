@extends('schools.layout')
@section('school')
<form action="{{route('school.update',$school->id)}}" method="post" enctype="multipart/form-data">
    @csrf
    @method('PUT')
    <label for="">Name</label><br>
    <input type="text" name="name" id="" value="{{$school->name}}"class="form-control"><br>
    <label for="">address</label><br>
    <input type="text" name="address" id="" value="{{$school->address}}"class="form-control"><br>
    <label for="">year</label><br>
    <input type="number" name="year" id="" value="{{$school->year}}"class="form-control"><br>
    <label for="">student</label><br>
    <input type="number" name="student" id="" value="{{$school->student}}"class="form-control"><br>
    <label class="font-weight-bold">Update image</label><br>
    <input type="file" class="form-control" name="image"><br><br>

    <input type="submit" value="update" class="btn btn-primary">


</form>
@endsection
