@extends('schools.layout')
@section('school')
<form action="{{route('school.store')}}" method="post" enctype="multipart/form-data" class="form">
    @csrf
    <label for="">Name </label><br>
    <input type="text" name="name"><br>
    <label for="">address</label><br>
    <input type="text" name="address"><br>
    <label for="">year</label><br>
    <input type="number" name="year"><br>
    <label for="">student</label><br>
    <input type="number" name="student"><br>
    <label for="">Upload image</label>
    <input type="file" name="image" id=""><br><br>

    <input type="submit" value="Save"class="btn btn-primary" . > <button type="reset" class="btn btn-md btn-dark">Reset</button>


</form>
@endsection
