<?php $__env->startSection('school'); ?>
<form action="<?php echo e(route('school.update',$school->id)); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <label for="">Name</label><br>
    <input type="text" name="name" id="" value="<?php echo e($school->name); ?>"class="form-control"><br>
    <label for="">address</label><br>
    <input type="text" name="address" id="" value="<?php echo e($school->address); ?>"class="form-control"><br>
    <label for="">year</label><br>
    <input type="number" name="year" id="" value="<?php echo e($school->year); ?>"class="form-control"><br>
    <label for="">student</label><br>
    <input type="number" name="student" id="" value="<?php echo e($school->student); ?>"class="form-control"><br>
    <label class="font-weight-bold">Update image</label><br>
    <input type="file" class="form-control" name="image"><br><br>

    <input type="submit" value="update" class="btn btn-primary">


</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('schools.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Desktop/school-app/resources/views/schools/edit.blade.php ENDPATH**/ ?>