<?php $__env->startSection('school'); ?>
<a href="<?php echo e(route('school.create')); ?>" class="btn btn-primary">ADD</a>
<table class="table">
    <tr>
        <th>Id</th>
        <th>image</th>
        <th>nama</th>
        <th>address</th>
        <th>year</th>
        <th>student</th>
        <th>action</th>

    </tr>
    <?php $__currentLoopData = $school; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($p->id); ?></td>
        <td><img src="<?php echo e(Storage::url('public/images/'. $p->image)); ?>" style="width: 150px;" alt=""></td>
        <td><?php echo e($p->name); ?></td>
        <td><?php echo e($p->address); ?></td>
        <td><?php echo e($p->year); ?></td>
        <td><?php echo e($p->student); ?></td>
        <td>
            <a href="<?php echo e(route('school.show',$p->id)); ?>" class="btn btn-success">Details</a>
            <a href="<?php echo e(route('school.edit',$p->id)); ?>" class="btn btn-secondary">edit</a>
            <form action="<?php echo e(route('school.destroy', $p->id)); ?>" method="POST" style="display: inline;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">DELETE</button>
            </form></td> </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
</table><?php echo e($school->links()); ?>  <?php $__env->stopSection(); ?> 
<?php echo $__env->make('schools.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Desktop/school-app/resources/views/schools/index.blade.php ENDPATH**/ ?>